"""Módulo GUI da aplicação."""
